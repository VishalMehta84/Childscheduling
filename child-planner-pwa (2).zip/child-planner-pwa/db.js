/**
 * db.js — IndexedDB layer for Child Planner PWA
 * Stores: events, topics, tests, files
 * All data lives on-device. No server required.
 */

const DB_NAME = 'ChildPlannerDB';
const DB_VERSION = 1;
const STORES = ['events', 'topics', 'tests', 'files'];

let _db = null;

/** Open (or upgrade) the database */
export function openDB() {
  if (_db) return Promise.resolve(_db);
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = e => {
      const db = e.target.result;
      STORES.forEach(name => {
        if (!db.objectStoreNames.contains(name)) {
          const store = db.createObjectStore(name, { keyPath: 'id' });
          if (name === 'events')  store.createIndex('day',     'day',     { unique: false });
          if (name === 'topics')  store.createIndex('subject', 'subject', { unique: false });
          if (name === 'tests')   store.createIndex('date',    'date',    { unique: false });
          if (name === 'files')   store.createIndex('linkedTo','linkedTo',{ unique: false });
        }
      });
    };

    req.onsuccess  = e => { _db = e.target.result; resolve(_db); };
    req.onerror    = e => reject(e.target.error);
  });
}

/** Generic helpers */
function tx(storeName, mode = 'readonly') {
  return _db.transaction(storeName, mode).objectStore(storeName);
}
function promisify(req) {
  return new Promise((res, rej) => {
    req.onsuccess = e => res(e.target.result);
    req.onerror   = e => rej(e.target.error);
  });
}

// ─── CRUD ────────────────────────────────────────────────────────────────────

/** Get all records from a store */
export async function getAll(storeName) {
  await openDB();
  return promisify(tx(storeName).getAll());
}

/** Get one record by id */
export async function getOne(storeName, id) {
  await openDB();
  return promisify(tx(storeName).get(id));
}

/** Create or fully replace a record (upsert) */
export async function upsert(storeName, record) {
  await openDB();
  if (!record.id) record.id = uid();
  record.updatedAt = new Date().toISOString();
  if (!record.createdAt) record.createdAt = record.updatedAt;
  return promisify(tx(storeName, 'readwrite').put(record));
}

/** Delete a record by id */
export async function remove(storeName, id) {
  await openDB();
  return promisify(tx(storeName, 'readwrite').delete(id));
}

/** Query by index value */
export async function queryByIndex(storeName, indexName, value) {
  await openDB();
  return promisify(tx(storeName).index(indexName).getAll(value));
}

/** Bulk import (replaces entire store) */
export async function bulkImport(storeName, records) {
  await openDB();
  const store = tx(storeName, 'readwrite');
  await promisify(store.clear());
  return Promise.all(records.map(r => promisify(store.put(r))));
}

// ─── File storage ─────────────────────────────────────────────────────────────

/**
 * Save a file's binary content on-device.
 * @param {File|Blob} file
 * @param {object} meta — { name, mimeType, linkedTo?, source? }
 */
export async function saveFile(file, meta = {}) {
  await openDB();
  const buffer = await file.arrayBuffer();
  const record = {
    id:         meta.id || uid(),
    name:       meta.name || file.name || 'file',
    mimeType:   meta.mimeType || file.type || 'application/octet-stream',
    size:       buffer.byteLength,
    linkedTo:   meta.linkedTo || null,   // e.g. topic id or test id
    source:     meta.source || 'local',  // 'local' | 'google-drive'
    driveId:    meta.driveId || null,
    data:       buffer,                  // ArrayBuffer stored in IDB
    createdAt:  new Date().toISOString(),
    updatedAt:  new Date().toISOString(),
  };
  await promisify(tx('files', 'readwrite').put(record));
  // Return a version without the binary for UI use
  const { data: _, ...light } = record;
  return light;
}

/** Get file metadata (no binary) */
export async function getFileMeta(id) {
  const record = await getOne('files', id);
  if (!record) return null;
  const { data: _, ...light } = record;
  return light;
}

/** Get all file metadata linked to an entity */
export async function getFilesFor(linkedTo) {
  await openDB();
  const all = await promisify(tx('files').index('linkedTo').getAll(linkedTo));
  return all.map(({ data: _, ...light }) => light);
}

/** Get all file metadata (no binaries) */
export async function getAllFilesMeta() {
  await openDB();
  const all = await promisify(tx('files').getAll());
  return all.map(({ data: _, ...light }) => light);
}

/** Open a file as a Blob URL for viewing/download */
export async function openFile(id) {
  const record = await getOne('files', id);
  if (!record || !record.data) throw new Error('File not found');
  const blob = new Blob([record.data], { type: record.mimeType });
  return URL.createObjectURL(blob);
}

/** Delete a file record */
export async function deleteFile(id) {
  return remove('files', id);
}

// ─── Export / Import ──────────────────────────────────────────────────────────

/** Export all non-file data as a JSON blob */
export async function exportJSON() {
  await openDB();
  const [events, topics, tests, files] = await Promise.all([
    getAll('events'), getAll('topics'), getAll('tests'), getAllFilesMeta()
  ]);
  const payload = JSON.stringify({ events, topics, tests, fileMeta: files, exportedAt: new Date().toISOString() }, null, 2);
  const blob = new Blob([payload], { type: 'application/json' });
  return blob;
}

/** Import data from a JSON blob (merges; does not delete existing) */
export async function importJSON(jsonText) {
  const payload = JSON.parse(jsonText);
  const ops = [];
  ['events', 'topics', 'tests'].forEach(store => {
    (payload[store] || []).forEach(r => ops.push(upsert(store, r)));
  });
  await Promise.all(ops);
  return { events: payload.events?.length || 0, topics: payload.topics?.length || 0, tests: payload.tests?.length || 0 };
}

// ─── Utility ──────────────────────────────────────────────────────────────────
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

export { uid };
